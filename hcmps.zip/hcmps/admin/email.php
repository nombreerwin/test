<!-- dashboard.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Management System</title>
</head>
<body>
    <h1>Appointment Scheduling</h1>
    <form action="appointment.php" method="post">
        <label for="patient_name">Patient Name:</label>
        <input type="text" id="patient_name" name="patient_name" required><br>
        <label for="patient_email">Patient Email:</label>
        <input type="email" id="patient_email" name="patient_email" required><br>
        <label for="appointment_date">Appointment Date:</label>
        <input type="date" id="appointment_date" name="appointment_date" required><br>
        <label for="appointment_time">Appointment Time:</label>
        <input type="time" id="appointment_time" name="appointment_time" required><br>
        <button type="submit">Schedule Appointment</button>
    </form>
</body>
</html>



<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $patientName = $_POST['patient_name'];
    $patientEmail = $_POST['patient_email'];
    $appointmentDate = $_POST['appointment_date'];
    $appointmentTime = $_POST['appointment_time'];
    $healthcareProviderEmail = "healthcare@example.com"; // Change this to your healthcare provider's email

    // Compose email message
    $subject = "Appointment Confirmation";
    $message = "Dear $patientName,\n\n";
    $message .= "Your appointment has been scheduled successfully.\n";
    $message .= "Date: $appointmentDate\n";
    $message .= "Time: $appointmentTime\n\n";
    $message .= "Thank you for choosing our healthcare services.\n\n";
    $message .= "Regards,\nHealthcare Management System";

    // Send email to patient
    $headers = "From: healthcare@example.com\r\n";
    $headers .= "Reply-To: healthcare@example.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    mail($patientEmail, $subject, $message, $headers);

    // Send email to healthcare provider
    $providerSubject = "New Appointment Scheduled";
    $providerMessage = "Dear Healthcare Provider,\n\n";
    $providerMessage .= "A new appointment has been scheduled by $patientName.\n";
    $providerMessage .= "Date: $appointmentDate\n";
    $providerMessage .= "Time: $appointmentTime\n";
    $providerMessage .= "Patient's Email: $patientEmail\n\n";
    $providerMessage .= "Please make necessary arrangements.\n\n";
    $providerMessage .= "Regards,\nHealthcare Management System";
    mail($healthcareProviderEmail, $providerSubject, $providerMessage, $headers);

    // Redirect to a confirmation page
    header("Location: confirmation.php");
    exit();
}
?>
