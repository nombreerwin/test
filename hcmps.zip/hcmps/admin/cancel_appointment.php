<?php
// Include database connection or any necessary classes

// Retrieve appointment ID from form
$appointment_id = $_POST['appointment_id'];

// Query to check if appointment exists
// Example assuming you have a MySQL database connection
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "healthcare_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if appointment exists
$sql = "SELECT * FROM appointments WHERE id = $appointment_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Appointment found, proceed with cancellation
    $row = $result->fetch_assoc();
    $patient_id = $row['patient_id'];
    $doctor_id = $row['doctor_id'];
    
    // Perform cancellation (e.g., update appointment status in database)
    $update_sql = "UPDATE appointments SET status = 'Cancelled' WHERE id = $appointment_id";
    if ($conn->query($update_sql) === TRUE) {
        echo "Appointment with ID $appointment_id has been cancelled successfully.";
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Appointment not found
    echo "Appointment with ID $appointment_id not found.";
}

$conn->close();
?>
